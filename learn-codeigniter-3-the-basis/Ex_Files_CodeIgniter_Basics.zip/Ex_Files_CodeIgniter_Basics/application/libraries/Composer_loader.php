<?php

class Composer_loader
{
	public function __construct()
	{
		include('./vendor/autoload.php');
	}
}