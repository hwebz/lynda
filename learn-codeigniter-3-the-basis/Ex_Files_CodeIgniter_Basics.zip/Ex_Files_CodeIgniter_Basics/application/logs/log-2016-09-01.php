DEBUG - 2016-09-01 14:06:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 14:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 14:06:53 --> My First Log
DEBUG - 2016-09-01 14:06:53 --> Total execution time: 0.0151
DEBUG - 2016-09-01 14:08:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 14:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 14:08:14 --> Form parametersArray
(
)

DEBUG - 2016-09-01 14:08:14 --> Total execution time: 0.0185
DEBUG - 2016-09-01 14:08:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 14:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 14:08:16 --> Form parametersArray
(
    [name] => New name
    [description] => New description
)

DEBUG - 2016-09-01 14:08:16 --> You did not select a file to upload.
DEBUG - 2016-09-01 14:08:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 14:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 14:08:16 --> My First Log
DEBUG - 2016-09-01 14:08:16 --> Total execution time: 0.0144
DEBUG - 2016-09-01 16:33:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 16:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 16:33:37 --> My First Log
DEBUG - 2016-09-01 16:33:37 --> Total execution time: 0.0304
DEBUG - 2016-09-01 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 16:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 16:33:41 --> My First Log
DEBUG - 2016-09-01 16:33:41 --> Total execution time: 0.0257
DEBUG - 2016-09-01 16:33:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 16:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 16:33:47 --> My First Log
DEBUG - 2016-09-01 16:33:47 --> Total execution time: 0.0258
DEBUG - 2016-09-01 16:34:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 16:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 16:34:00 --> My First Log
DEBUG - 2016-09-01 16:34:00 --> Total execution time: 0.0260
DEBUG - 2016-09-01 16:34:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 16:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 16:34:01 --> My First Log
DEBUG - 2016-09-01 16:34:01 --> Total execution time: 0.0264
DEBUG - 2016-09-01 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 16:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 16:34:03 --> My First Log
DEBUG - 2016-09-01 16:34:03 --> Total execution time: 0.0264
DEBUG - 2016-09-01 16:56:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 16:56:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-01 16:56:51 --> Severity: Warning --> include(./vendor/autoload.php): failed to open stream: No such file or directory /Applications/MAMP/htdocs/work/lynda/learn-code-igniter-3-the-basics/ExerciseFiles/final_files/03_02_start/application/libraries/Composer_loader.php 7
ERROR - 2016-09-01 16:56:51 --> Severity: Warning --> include(): Failed opening './vendor/autoload.php' for inclusion (include_path='.:/Applications/MAMP/bin/php/php7.0.0/lib/php') /Applications/MAMP/htdocs/work/lynda/learn-code-igniter-3-the-basics/ExerciseFiles/final_files/03_02_start/application/libraries/Composer_loader.php 7
ERROR - 2016-09-01 16:56:51 --> Severity: error --> Exception: Class 'Faker\Factory' not found /Applications/MAMP/htdocs/work/lynda/learn-code-igniter-3-the-basics/ExerciseFiles/final_files/03_02_start/application/controllers/Properties.php 9
ERROR - 2016-09-01 16:56:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/work/lynda/learn-code-igniter-3-the-basics/ExerciseFiles/final_files/03_02_start/system/core/Exceptions.php:272) /Applications/MAMP/htdocs/work/lynda/learn-code-igniter-3-the-basics/ExerciseFiles/final_files/03_02_start/system/core/Common.php 573
DEBUG - 2016-09-01 16:57:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 16:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 16:57:30 --> My First Log
DEBUG - 2016-09-01 16:57:30 --> Total execution time: 0.0857
DEBUG - 2016-09-01 16:58:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 16:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 16:58:23 --> My First Log
DEBUG - 2016-09-01 16:58:23 --> Total execution time: 0.0726
DEBUG - 2016-09-01 16:58:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 16:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 16:58:28 --> Form parametersArray
(
)

DEBUG - 2016-09-01 16:58:28 --> Total execution time: 0.0592
DEBUG - 2016-09-01 16:58:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 16:58:32 --> No URI present. Default controller set.
DEBUG - 2016-09-01 16:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 16:58:32 --> My First Log
DEBUG - 2016-09-01 16:58:32 --> Total execution time: 0.0828
DEBUG - 2016-09-01 16:59:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 16:59:08 --> No URI present. Default controller set.
DEBUG - 2016-09-01 16:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 16:59:08 --> My First Log
DEBUG - 2016-09-01 16:59:08 --> Total execution time: 0.0781
DEBUG - 2016-09-01 16:59:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 16:59:44 --> No URI present. Default controller set.
DEBUG - 2016-09-01 16:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 16:59:44 --> My First Log
DEBUG - 2016-09-01 16:59:44 --> Total execution time: 0.0650
DEBUG - 2016-09-01 17:00:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:00:14 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:00:14 --> My First Log
DEBUG - 2016-09-01 17:00:14 --> Total execution time: 0.0798
DEBUG - 2016-09-01 17:00:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:00:25 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:00:25 --> My First Log
DEBUG - 2016-09-01 17:00:25 --> Total execution time: 0.0774
DEBUG - 2016-09-01 17:00:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:00:42 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:00:42 --> My First Log
DEBUG - 2016-09-01 17:00:42 --> Total execution time: 0.0667
DEBUG - 2016-09-01 17:02:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:02:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:02:28 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:02:28 --> My First Log
DEBUG - 2016-09-01 17:02:28 --> Total execution time: 0.0703
DEBUG - 2016-09-01 17:02:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:02:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:02:45 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:02:45 --> My First Log
DEBUG - 2016-09-01 17:02:45 --> Total execution time: 0.0709
DEBUG - 2016-09-01 17:02:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:02:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:02:52 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:02:52 --> My First Log
DEBUG - 2016-09-01 17:02:52 --> Total execution time: 0.0737
DEBUG - 2016-09-01 17:06:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:06:03 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:06:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-09-01 17:06:03 --> Severity: Notice --> Undefined property: Properties::$db /Applications/MAMP/htdocs/work/lynda/learn-code-igniter-3-the-basics/ExerciseFiles/final_files/03_02_start/system/core/Model.php 77
ERROR - 2016-09-01 17:06:03 --> Severity: error --> Exception: Call to a member function get() on null /Applications/MAMP/htdocs/work/lynda/learn-code-igniter-3-the-basics/ExerciseFiles/final_files/03_02_start/application/models/Status.php 6
ERROR - 2016-09-01 17:06:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/work/lynda/learn-code-igniter-3-the-basics/ExerciseFiles/final_files/03_02_start/system/core/Exceptions.php:272) /Applications/MAMP/htdocs/work/lynda/learn-code-igniter-3-the-basics/ExerciseFiles/final_files/03_02_start/system/core/Common.php 573
DEBUG - 2016-09-01 17:06:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:06:21 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:06:21 --> My First Log
DEBUG - 2016-09-01 17:06:21 --> Total execution time: 0.0867
DEBUG - 2016-09-01 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:07:38 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:07:38 --> My First Log
DEBUG - 2016-09-01 17:07:38 --> Total execution time: 0.0862
DEBUG - 2016-09-01 17:09:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:09:04 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:09:04 --> My First Log
DEBUG - 2016-09-01 17:09:04 --> Total execution time: 0.0875
DEBUG - 2016-09-01 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:09:19 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:09:19 --> My First Log
DEBUG - 2016-09-01 17:09:19 --> Total execution time: 0.0719
DEBUG - 2016-09-01 17:09:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:09:32 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:09:32 --> My First Log
DEBUG - 2016-09-01 17:09:32 --> Total execution time: 0.0787
DEBUG - 2016-09-01 17:10:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:10:03 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:10:03 --> My First Log
DEBUG - 2016-09-01 17:10:03 --> Total execution time: 0.0726
DEBUG - 2016-09-01 17:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:10:13 --> Form parametersArray
(
)

DEBUG - 2016-09-01 17:10:13 --> Total execution time: 0.0544
DEBUG - 2016-09-01 17:13:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:13:19 --> Form parametersArray
(
)

DEBUG - 2016-09-01 17:13:19 --> Total execution time: 0.0555
DEBUG - 2016-09-01 17:17:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:17:25 --> Form parametersArray
(
)

ERROR - 2016-09-01 17:17:25 --> Query error: Table 'ci_course.agent' doesn't exist - Invalid query: SELECT *
FROM `agent`
DEBUG - 2016-09-01 17:17:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:17:34 --> Form parametersArray
(
)

DEBUG - 2016-09-01 17:17:34 --> Total execution time: 0.0725
DEBUG - 2016-09-01 17:18:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:18:08 --> Form parametersArray
(
)

DEBUG - 2016-09-01 17:18:08 --> Total execution time: 0.0581
DEBUG - 2016-09-01 17:18:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:18:46 --> Form parametersArray
(
)

DEBUG - 2016-09-01 17:18:46 --> Total execution time: 0.0595
DEBUG - 2016-09-01 17:19:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:19:18 --> Form parametersArray
(
)

DEBUG - 2016-09-01 17:19:18 --> Total execution time: 0.0600
DEBUG - 2016-09-01 17:19:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:19:29 --> Form parametersArray
(
)

DEBUG - 2016-09-01 17:19:29 --> Total execution time: 0.0592
DEBUG - 2016-09-01 17:23:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:23:02 --> Form parametersArray
(
    [name] => 1
    [description] => 2
    [street] => 3
    [city] => 4
    [state] => 5
    [zip_code] => 6
    [latitude] => 7
    [longitude] => 8
    [agents_id] => 2
    [status_id] => 2
)

DEBUG - 2016-09-01 17:23:02 --> You did not select a file to upload.
DEBUG - 2016-09-01 17:23:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:23:02 --> My First Log
DEBUG - 2016-09-01 17:23:02 --> Total execution time: 0.0805
DEBUG - 2016-09-01 17:23:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:23:07 --> Form parametersArray
(
)

DEBUG - 2016-09-01 17:23:07 --> Total execution time: 0.0603
DEBUG - 2016-09-01 17:23:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:23:37 --> Form parametersArray
(
    [name] => 1
    [description] => 2
    [street] => 3
    [city] => 4
    [state] => 5
    [zip_code] => 6
    [latitude] => 7
    [longitude] => 8
    [agents_id] => 1
    [status_id] => 3
)

DEBUG - 2016-09-01 17:23:37 --> You did not select a file to upload.
DEBUG - 2016-09-01 17:23:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:23:37 --> My First Log
DEBUG - 2016-09-01 17:23:37 --> Total execution time: 0.0811
DEBUG - 2016-09-01 17:23:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:23:43 --> Form parametersArray
(
)

DEBUG - 2016-09-01 17:23:43 --> Total execution time: 0.0562
DEBUG - 2016-09-01 17:25:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:25:01 --> Form parametersArray
(
)

DEBUG - 2016-09-01 17:25:01 --> Total execution time: 0.0591
DEBUG - 2016-09-01 17:25:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:25:03 --> My First Log
DEBUG - 2016-09-01 17:25:03 --> Total execution time: 0.0779
DEBUG - 2016-09-01 17:25:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:25:11 --> My First Log
DEBUG - 2016-09-01 17:25:11 --> Total execution time: 0.0706
DEBUG - 2016-09-01 17:26:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:26:29 --> Form parametersArray
(
)

DEBUG - 2016-09-01 17:26:29 --> Total execution time: 0.0660
DEBUG - 2016-09-01 17:26:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:26:31 --> My First Log
DEBUG - 2016-09-01 17:26:31 --> Total execution time: 0.0708
DEBUG - 2016-09-01 17:27:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:27:07 --> My First Log
DEBUG - 2016-09-01 17:27:07 --> Total execution time: 0.0738
DEBUG - 2016-09-01 17:27:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:27:12 --> Total execution time: 0.0496
DEBUG - 2016-09-01 17:29:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:29:10 --> Total execution time: 0.0501
DEBUG - 2016-09-01 17:29:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:29:41 --> Total execution time: 0.0497
DEBUG - 2016-09-01 17:30:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:30:09 --> Form parametersArray
(
)

DEBUG - 2016-09-01 17:30:09 --> Total execution time: 0.0727
DEBUG - 2016-09-01 17:30:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:30:13 --> My First Log
DEBUG - 2016-09-01 17:30:13 --> Total execution time: 0.0955
DEBUG - 2016-09-01 17:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:31:38 --> No URI present. Default controller set.
DEBUG - 2016-09-01 17:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:31:38 --> My First Log
DEBUG - 2016-09-01 17:31:38 --> Total execution time: 0.0756
DEBUG - 2016-09-01 17:31:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 17:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 17:31:45 --> Total execution time: 0.0527
DEBUG - 2016-09-01 18:07:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 18:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 18:07:47 --> My First Log
DEBUG - 2016-09-01 18:07:47 --> Total execution time: 0.0316
DEBUG - 2016-09-01 18:08:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 18:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 18:08:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 18:08:03 --> No URI present. Default controller set.
DEBUG - 2016-09-01 18:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 18:08:03 --> My First Log
DEBUG - 2016-09-01 18:08:03 --> Total execution time: 0.0262
DEBUG - 2016-09-01 18:08:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 18:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 18:08:13 --> Form parametersArray
(
)

DEBUG - 2016-09-01 18:08:13 --> Total execution time: 0.0205
DEBUG - 2016-09-01 18:08:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 18:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 18:08:54 --> Form parametersArray
(
    [name] => Spacious Classic Home
    [description] => Situated on 1 acre with a wraparound driveway, sits this beautiful 4400 sq. foot, 6 bedroom, 3.5 bath brick home. Located at the top of the foothills with scenic views of the valley, this home is an entertainer's dream. Master chef's kitchen with double oven and all stainless steel appliances. Game room with a built in bar, and large back yard for year round entertainment.
    [street] => 148 Euclid Ave.
    [city] => Loveland
    [state] => CO
    [zip_code] => 80537
    [latitude] => 39.754990
    [longitude] => -104.939604
    [agents_id] => 1
    [status_id] => 1
)

DEBUG - 2016-09-01 18:08:54 --> You did not select a file to upload.
DEBUG - 2016-09-01 18:08:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 18:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 18:08:54 --> My First Log
DEBUG - 2016-09-01 18:08:54 --> Total execution time: 0.0282
DEBUG - 2016-09-01 18:09:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 18:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 18:09:03 --> Total execution time: 0.0154
DEBUG - 2016-09-01 18:10:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 18:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 18:10:35 --> Total execution time: 0.0158
DEBUG - 2016-09-01 18:11:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 18:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 18:11:27 --> Total execution time: 0.0156
DEBUG - 2016-09-01 18:12:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 18:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 18:12:18 --> Total execution time: 0.0154
DEBUG - 2016-09-01 18:13:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-01 18:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-09-01 18:13:06 --> Form parametersArray
(
)

DEBUG - 2016-09-01 18:13:06 --> Total execution time: 0.0213
