        <hr>
        <footer class="callout large secondary">
          <div class="row">
            <div class="large-12 columns">
              <h5>Loading Views</h5>
              <p>examples by: <a href="https://twitter.com/bpineda">@bpineda</a></p>
              </h4>
            </div>
          </div>
        </footer>
        <script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
        <script src="http://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.js"></script>
        <script>
          $(document).foundation();
        </script>

    </body>
</html>