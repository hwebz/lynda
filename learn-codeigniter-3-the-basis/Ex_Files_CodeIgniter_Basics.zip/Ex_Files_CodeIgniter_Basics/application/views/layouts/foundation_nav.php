<div class="main-nav title-bar " data-responsive-toggle="example-menu" data-hide-for="medium">
  <button class="menu-icon" type="button" data-toggle></button>
  <div class="title-bar-title"></div>
</div>
<div class="main-nav top-bar" id="example-menu">
  <div class="top-bar-left">
    <ul class="menu">
      <li><a href="<?php echo site_url(''); ?>">Properties</a></li>
    </ul>
  </div>
</div>