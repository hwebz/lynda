<h3>Record <?php echo $id; ?> , has the name <?php echo $name; ?></h3>
<p>MySQL version: <?php echo $version; ?></p>