<div class="alert alert-success">
	Magazine <?php echo html_escape($issue->issue_number); ?> created!
</div>