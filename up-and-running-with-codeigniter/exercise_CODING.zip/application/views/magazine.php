<div class="magazine">
	<div class="name_isse">
		<?php echo html_escape($publication->publication_name); ?>
		#<?php echo html_escape($issue->issue_number); ?>
	</div>
	<div class="date">
		<?php echo html_escape($issue->issue_date_publication); ?>
	</div>
	<?php if ($issue->issue_cover) : ?>
		<div class="cover">
			<?php echo img('uploads/'.$issue->issue_cover); ?>
		</div>
	<?php endif; ?>
</div>