import {Component} from '@angular/core';

@Component({
    selector: 'video-toolbar',
    template: `
    <div id="playerToolBar"></div>
    `
})
export class ToolbarComponent {
    constructor() {}
}
