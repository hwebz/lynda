export class AuthController {

}