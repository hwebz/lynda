export class MainController {
  constructor ($http) {
    'ngInject';


  }

    postMessage() {
        console.log("post");
    }

}
