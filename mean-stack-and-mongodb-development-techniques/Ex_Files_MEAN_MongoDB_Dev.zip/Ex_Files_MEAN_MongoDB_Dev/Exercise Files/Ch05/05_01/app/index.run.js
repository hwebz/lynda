export function runBlock ($log) {
  'ngInject';
  $log.debug('runBlock end');
}
