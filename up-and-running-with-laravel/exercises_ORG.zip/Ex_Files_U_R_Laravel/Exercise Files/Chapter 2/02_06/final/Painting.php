<?php

class Painting extends Eloquent
{
    
}
