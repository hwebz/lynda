<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thanks for signing up!</title>
    <style>

    </style>
</head>

<body>
<h1>Thanks! We'll send your first email to: {{ $theEmail }}</h1>

</body>
</html>