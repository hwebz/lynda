<?php

class TrueTest extends TestCase {

	/**
	 * A basic functional test example.
	 *
	 * @return void
	 */
	public function testTrue()
	{
		$theTruth = true;

		$this->assertTrue($theTruth);
	}

}
