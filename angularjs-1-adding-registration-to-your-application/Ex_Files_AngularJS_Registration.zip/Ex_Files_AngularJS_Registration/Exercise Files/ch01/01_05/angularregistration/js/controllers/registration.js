myApp.controller('RegistrationController', ['$scope', function($scope) {
  $scope.message = "Welcome to my App";
}]);