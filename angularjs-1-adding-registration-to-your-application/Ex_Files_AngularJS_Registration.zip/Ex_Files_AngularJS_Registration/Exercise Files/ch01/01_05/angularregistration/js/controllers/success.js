myApp.controller('SuccessController', ['$scope', function($scope) {
  $scope.message = "Success!!!";
}]);