export {SandoAppComponent} from './sando-app.component';
