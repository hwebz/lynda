import { bootstrap } from '@angular/platform-browser-dynamic';
import { enableProdMode } from '@angular/core';
import { SandoAppComponent } from './app/';

enableProdMode();

bootstrap(SandoAppComponent);
