<?php
/**
 * IssueFixture
 *
 */
class IssueFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'issue_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'key' => 'primary'),
		'issue_publication_id' => array('type' => 'integer', 'null' => true, 'default' => null),
		'issue_number' => array('type' => 'integer', 'null' => true, 'default' => null),
		'issue_date_publication' => array('type' => 'date', 'null' => true, 'default' => null),
		'issue_cover' => array('type' => 'string', 'null' => true, 'default' => null, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'indexes' => array(
			'PRIMARY' => array('column' => 'issue_id', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_general_ci', 'engine' => 'MyISAM')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'issue_id' => 1,
			'issue_publication_id' => 1,
			'issue_number' => 1,
			'issue_date_publication' => '2016-06-26',
			'issue_cover' => 'Lorem ipsum dolor sit amet'
		),
	);

}
